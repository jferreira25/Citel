﻿using Citel.Admin.Compras.CrossCutting.Configuration;
using Citel.Admin.Compras.Domain.Interfaces;
using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Infrastructure.Data.Repository.Category
{
    public class CategoryRepository: ICategoryRepository
    {
        protected IDbConnection Connection => new MySqlConnection(AppSettings.Settings.MySqlconnections.ConnectionString);

        public async Task<Domain.Entities.Category> GetByNameAsync(string name)
        {
            var stringSql = "SELECT id,name,description FROM category WHERE name=@name";

            return await Connection.QueryFirstOrDefaultAsync<Domain.Entities.Category>(stringSql, new { name });
        }

        public async Task<Domain.Entities.Category> GetByIdAsync(long id)
        {
            var stringSql = "SELECT id,name,description FROM category WHERE id=@id";

            return await Connection.QueryFirstOrDefaultAsync<Domain.Entities.Category>(stringSql, new { id });
        }

        public async Task<IEnumerable<Domain.Entities.Category>> GetAllAsync()
        {
            var stringSql = "SELECT id,name,description FROM category";

            return await Connection.QueryAsync<Domain.Entities.Category>(stringSql);
        }

        public async Task<long> AddAsync(Domain.Entities.Category category)
        {
            var stringSql = new StringBuilder()
                            .Append(@"INSERT INTO category (name,description)
                                          VALUES (@Name, @Description);
                                          SELECT LAST_INSERT_ID();");

            var id = Convert.ToInt64(await Connection.ExecuteScalarAsync(stringSql.ToString(),
                new
                {
                    category.Name,
                    category.Description

                }));

            return (long)id;
        }

        public async Task<bool> DeleteAsync(long id)
        {
            var stringSql = "DELETE FROM category WHERE ID = @id";

            await Connection.ExecuteAsync(stringSql.ToString(), new { id });

            return true;
        }

        public async Task<bool> UpdateAsync(Domain.Entities.Category category)
        {
            var stringSql = new StringBuilder()
                            .Append(@"UPDATE category SET
                                             name = @name, 
                                             description = @description
                                      WHERE ID = @Id");

            await Connection.ExecuteAsync(stringSql.ToString(), new
            {
                category.Name,
                category.Description,
                category.Id
            });

            return true;
        }

    }
}
