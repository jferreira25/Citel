﻿using Citel.Admin.Compras.Domain.Commands.Product.Create;
using Citel.Admin.Compras.Tests.Shared.Mock.CommandHandler.Commands.Products.CreateProduct;
using Citel.Admin.Compras.Tests.Shared.Mock.Infrastructure.Database.MySql;
using Citel.Admin.Compras.Tests.Shared.Mock.Injection.Mappers;
using NUnit.Framework;
using System.Threading;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Tests.Unity.Domain.CommandHandler.Products.CreateProduct
{
    public  class CreateProductCommandHandlerTest
    {
        protected  CreateProductCommandHandler EstablishContext() => new CreateProductCommandHandler(
             new ProductRepositoryMock().GetDefaultInstance().Object,
           MappersMock.GetMock()
          
       );

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task Test_AddProductCommandHandler()
        {
            var request = CreateProductCommandMock.GetDefaultInstance();

            var response = await EstablishContext().Handle(request, CancellationToken.None);

            Assert.IsNotNull(response);
        }
    }
}
