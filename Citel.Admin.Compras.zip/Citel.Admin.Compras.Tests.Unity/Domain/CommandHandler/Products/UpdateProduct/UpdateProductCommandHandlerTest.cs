﻿using Citel.Admin.Compras.Domain.Commands.Product.Update;
using Citel.Admin.Compras.Tests.Shared.Mock.CommandHandler.Commands.Products.UpdateProduct;
using Citel.Admin.Compras.Tests.Shared.Mock.Infrastructure.Database.MySql;
using Citel.Admin.Compras.Tests.Shared.Mock.Injection.Mappers;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Tests.Unity.Domain.CommandHandler.Products.UpdateProduct
{
    public class UpdateProductCommandHandlerTest
    {
        protected UpdateProductCommandHandler EstablishContext() => new UpdateProductCommandHandler(
               new ProductRepositoryMock().GetDefaultInstance().Object,
             MappersMock.GetMock()

         );

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task Test_UpdateProductCommandHandler()
        {
            var request = UpdateProductCommandMock.GetDefaultInstance();

            var response = await EstablishContext().Handle(request, CancellationToken.None);

            Assert.IsNotNull(response);
        }
    }
}
