﻿namespace Citel.Admin.Compras.Tests.Shared.Mock.Domain.Entities.Product
{
    public static class ProductMock
    {
        public static Compras.Domain.Entities.Product GetDefaultInstance() => new Compras.Domain.Entities.Product
        {
            Id = 0,
            Category =1,
            Description = "teste mock",
            Price = 2.99,
            Name = "Mock"
        };
    }
}
