﻿namespace Citel.Admin.Compras.Tests.Shared.Mock.Domain.Entities.Category
{
    public static class CategoryMock
    {
        public static Compras.Domain.Entities.Category GetDefaultInstance() => new Compras.Domain.Entities.Category
        {
            Id = 0,
            Description = "teste mock",
            Name = "Mock"
        };
    }
}
