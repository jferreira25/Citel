﻿using Citel.Admin.Compras.Domain.Entities;
using Citel.Admin.Compras.Domain.Interfaces;
using Citel.Admin.Compras.Tests.Shared.Core;
using Citel.Admin.Compras.Tests.Shared.Mock.Domain.Entities.Product;
using Moq;
using System.Collections.Generic;

namespace Citel.Admin.Compras.Tests.Shared.Mock.Infrastructure.Database.MySql
{
    public class ProductRepositoryMock : BaseMock<IProductRepository>
    {
        public override Mock<IProductRepository> GetDefaultInstance()
        {
            ProductRepository();
            return Mock;
        }

        private void ProductRepository()
        {
            Setup(r => r.AddAsync(It.IsAny<Product>()), 1);
            Setup(r => r.UpdateAsync(It.IsAny<Product>()), true);
            Setup(r => r.DeleteAsync(It.IsAny<long>()), true);
            Setup(r => r.GetByIdAsync(It.IsAny<long>()), ProductMock.GetDefaultInstance());
            Setup(r => r.GetAllAsync(), new List<Product>());
        }
    }
}
