﻿using Citel.Admin.Compras.Domain.Entities;
using Citel.Admin.Compras.Domain.Interfaces;
using Citel.Admin.Compras.Tests.Shared.Core;
using Citel.Admin.Compras.Tests.Shared.Mock.Domain.Entities.Category;
using Moq;
using System.Collections.Generic;

namespace Citel.Admin.Compras.Tests.Shared.Mock.Infrastructure.Database.MySql
{
    class CategoryRepositoryMock : BaseMock<ICategoryRepository>
    {
        public override Mock<ICategoryRepository> GetDefaultInstance()
        {
            CategoryRepository();
            return Mock;
        }

        private void CategoryRepository()
        {
            Setup(r => r.AddAsync(It.IsAny<Category>()), 1);
            Setup(r => r.UpdateAsync(It.IsAny<Category>()), true);
            Setup(r => r.DeleteAsync(It.IsAny<long>()), true);
            Setup(r => r.GetByIdAsync(It.IsAny<long>()), CategoryMock.GetDefaultInstance());
            Setup(r => r.GetAllAsync(), new List<Category>());
        }
    }
}
