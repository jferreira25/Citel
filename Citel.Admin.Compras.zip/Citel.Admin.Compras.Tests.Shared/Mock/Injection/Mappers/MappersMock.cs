﻿using AutoMapper;
using Citel.Admin.Compras.Domain.MappersProfile;

namespace Citel.Admin.Compras.Tests.Shared.Mock.Injection.Mappers
{
    public static class MappersMock
    {
        public static IMapper GetMock()
        {
            var configuration = new MapperConfiguration(
                cfg =>
                {
                    cfg.AddProfile<CategoryProfile>();
                    cfg.AddProfile<ProductProfile>();
                   
                });

            return new Mapper(configuration);
        }
    }
}
