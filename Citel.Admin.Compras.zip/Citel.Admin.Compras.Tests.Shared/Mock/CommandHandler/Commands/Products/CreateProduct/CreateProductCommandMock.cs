﻿using Citel.Admin.Compras.Domain.Commands.Product.Create;

namespace Citel.Admin.Compras.Tests.Shared.Mock.CommandHandler.Commands.Products.CreateProduct
{
    public static class CreateProductCommandMock
    {
        public static CreateProductCommand GetDefaultInstance() =>
             new CreateProductCommand
             {
                 Name = "Name Test",
                 Category = 1,
                 Description = "Description test",
                 Price = 29.99
             };
    }
}