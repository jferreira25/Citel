﻿using Citel.Admin.Compras.Domain.Commands.Product.Update;

namespace Citel.Admin.Compras.Tests.Shared.Mock.CommandHandler.Commands.Products.UpdateProduct
{
    public class UpdateProductCommandMock
    {
        public static UpdateProductCommand GetDefaultInstance() =>
              new UpdateProductCommand
              {
                  Name = "Name Test",
                  Category = 1,
                  Description = "Description test",
                  Price = 29.99
              };
    }
}