﻿using Citel.Admin.Compras.CrossCutting.Configuration.AppModels;
using Newtonsoft.Json;

namespace Citel.Admin.Compras.CrossCutting.Configuration
{
    public class AppSettings: Settings
    {
        public static AppSettings Settings => AppFileConfiguration<AppSettings>.Settings;

        [JsonProperty("mySqlconnections")]
        public MySqlConnection MySqlconnections { get; set; }
    }
}
