﻿using Newtonsoft.Json;

namespace Citel.Admin.Compras.CrossCutting.Configuration.AppModels
{
    public class MySqlConnection
    {
        [JsonProperty("connectionString")]
        public string ConnectionString { get; set; }
    }
}
