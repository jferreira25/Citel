﻿using Newtonsoft.Json;

namespace Citel.Admin.Compras.CrossCutting.Configuration
{
    public class Settings
    {
        [JsonProperty(PropertyName = "applicationName")]
        public string ApplicationName { get; set; }
    }
}
