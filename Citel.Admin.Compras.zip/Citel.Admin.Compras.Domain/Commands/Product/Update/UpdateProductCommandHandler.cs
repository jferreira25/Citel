﻿using AutoMapper;
using Citel.Admin.Compras.Domain.Interfaces;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Domain.Commands.Product.Update
{
    public class UpdateProductCommandHandler : IRequestHandler<UpdateProductCommand, Unit>
    {
        private readonly IProductRepository _productRepository;
        private readonly IMapper _mapper;
        public UpdateProductCommandHandler(
            IProductRepository productRepository,
            IMapper mapper
            )
        {
            _productRepository = productRepository;
            _mapper = mapper;
        }

        public async Task<Unit> Handle(UpdateProductCommand request, CancellationToken cancellationToken)
        {
            var product = _mapper.Map<Entities.Product>(request);
            await _productRepository.UpdateAsync(product);

            return Unit.Value;
        }
    }
}
