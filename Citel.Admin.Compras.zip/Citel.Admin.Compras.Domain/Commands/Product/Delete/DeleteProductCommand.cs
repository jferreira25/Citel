﻿using MediatR;

namespace Citel.Admin.Compras.Domain.Commands.Product.Delete
{
    public class DeleteProductCommand : IRequest
    {
        public DeleteProductCommand(long id)
        {
            Id = id;
        }

        public long Id { get; set; }
    }
}
