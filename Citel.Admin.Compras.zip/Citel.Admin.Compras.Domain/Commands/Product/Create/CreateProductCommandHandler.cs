﻿
using AutoMapper;
using Citel.Admin.Compras.Domain.Interfaces;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Domain.Commands.Product.Create
{
    public class CreateProductCommandHandler : IRequestHandler<CreateProductCommand, CreateProductCommandResponse>
    {
        private readonly IProductRepository _productRepository;
        private readonly IMapper _mapper;
        public CreateProductCommandHandler(
            IProductRepository productRepository,
            IMapper mapper
            )
        {
            _productRepository = productRepository;
            _mapper = mapper;
        }
        public async Task<CreateProductCommandResponse> Handle(CreateProductCommand request, CancellationToken cancellationToken)
        {
            var product = _mapper.Map<Entities.Product>(request);

            var id = await _productRepository.AddAsync(product);

            return new CreateProductCommandResponse(id);
        }
    }
}
