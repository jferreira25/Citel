﻿namespace Citel.Admin.Compras.Domain.Commands.Product.Create
{
    public class CreateProductCommandResponse
    {
        public CreateProductCommandResponse(long id)
        {
            this.id = id;
        }

        public long id { get; set; }
    }
}
