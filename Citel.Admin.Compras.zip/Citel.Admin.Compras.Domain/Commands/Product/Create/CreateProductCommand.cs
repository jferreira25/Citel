﻿using MediatR;

namespace Citel.Admin.Compras.Domain.Commands.Product.Create
{
    public class CreateProductCommand: IRequest<CreateProductCommandResponse>
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public long Category { get; set; }
    }
}
