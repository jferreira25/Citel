﻿using MediatR;

namespace Citel.Admin.Compras.Domain.Commands.Category.Create
{
    public class CreateCategoryCommand : IRequest<CreateCategoryCommandResponse>
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
