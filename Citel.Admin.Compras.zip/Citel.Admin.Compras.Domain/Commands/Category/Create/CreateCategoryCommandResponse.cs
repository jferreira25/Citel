﻿namespace Citel.Admin.Compras.Domain.Commands.Category.Create
{
    public class CreateCategoryCommandResponse
    {
        public CreateCategoryCommandResponse(long id)
        {
            Id = id;
        }

        public long Id { get; set; }
    }
}
