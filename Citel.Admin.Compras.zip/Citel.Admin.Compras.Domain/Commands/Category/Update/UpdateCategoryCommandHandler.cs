﻿using AutoMapper;
using Citel.Admin.Compras.Domain.Interfaces;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Domain.Commands.Category.Update
{
    public class UpdateCategoryCommandHandler : IRequestHandler<UpdateCategoryCommand, Unit>
    {
        private readonly ICategoryRepository _categoryRepository;
        private readonly IMapper _mapper;
        public UpdateCategoryCommandHandler(
            ICategoryRepository categoryRepository,
            IMapper mapper
            )
        {
            _categoryRepository = categoryRepository;
            _mapper = mapper;
        }

        public async Task<Unit> Handle(UpdateCategoryCommand request, CancellationToken cancellationToken)
        {
            var category = _mapper.Map<Entities.Category>(request);

            await _categoryRepository.UpdateAsync(category);

            return Unit.Value;
        }
    }
}
