﻿using MediatR;

namespace Citel.Admin.Compras.Domain.Commands.Category.Delete
{
    public class DeleteCategoryCommand : IRequest
    {
        public DeleteCategoryCommand(long id)
        {
            Id = id;
        }

        public long Id { get; set; }
    }
}
