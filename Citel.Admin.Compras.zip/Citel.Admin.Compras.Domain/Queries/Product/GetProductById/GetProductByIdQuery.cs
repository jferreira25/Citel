﻿using MediatR;

namespace Citel.Admin.Compras.Domain.Queries.Product.GetProductById
{
    public class GetProductByIdQuery : IRequest<GetProductByIdQueryResponse>
    {
        public long Id { get; set; }

        public GetProductByIdQuery(long id)
        {
            Id = id;
        }
    }
}
