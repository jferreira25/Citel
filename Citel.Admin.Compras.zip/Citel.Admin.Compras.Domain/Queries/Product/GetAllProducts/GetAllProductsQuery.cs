﻿using MediatR;

namespace Citel.Admin.Compras.Domain.Queries.Product.GetAllProducts
{
    public class GetAllProductsQuery : IRequest<GetAllProductsQueryResponse>
    {
    }
}
