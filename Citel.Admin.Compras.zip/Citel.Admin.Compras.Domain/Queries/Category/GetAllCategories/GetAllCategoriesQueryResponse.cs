﻿using System.Collections.Generic;

namespace Citel.Admin.Compras.Domain.Queries.Category.GetAllCategories
{
    public class GetAllCategoriesQueryResponse
    {
        public List<GetCategoryQueryResponse> Categories { get; set; }
    }
    public class GetCategoryQueryResponse
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
