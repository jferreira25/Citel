﻿using MediatR;

namespace Citel.Admin.Compras.Domain.Queries.Category.GetAllCategories
{
    public class GetAllCategoriesQuery : IRequest<GetAllCategoriesQueryResponse>
    {
    }
}
