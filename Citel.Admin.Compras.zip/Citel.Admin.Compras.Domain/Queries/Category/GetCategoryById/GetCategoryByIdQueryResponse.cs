﻿namespace Citel.Admin.Compras.Domain.Queries.Category.GetCategoryById
{
    public class GetCategoryByIdQueryResponse
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
