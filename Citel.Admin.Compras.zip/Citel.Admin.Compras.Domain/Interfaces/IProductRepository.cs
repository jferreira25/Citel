﻿using Citel.Admin.Compras.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Domain.Interfaces
{
    public interface  IProductRepository
    {
         Task<Product> GetByNameAsync(string name);
         Task<long> AddAsync(Product product);
         Task<Product> GetByIdAsync(long id);
         Task<IEnumerable<Product>> GetAllAsync();
         Task<bool> DeleteAsync(long id);
         Task<bool> UpdateAsync(Product product);
    }
}
