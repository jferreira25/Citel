﻿using Citel.Admin.Compras.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Domain.Interfaces
{
    public interface  ICategoryRepository
    {
        Task<Category> GetByNameAsync(string name);
        Task<long> AddAsync(Category product);
        Task<Category> GetByIdAsync(long id);
        Task<IEnumerable<Category>> GetAllAsync();
        Task<bool> DeleteAsync(long id);
        Task<bool> UpdateAsync(Category category);
    }
}
