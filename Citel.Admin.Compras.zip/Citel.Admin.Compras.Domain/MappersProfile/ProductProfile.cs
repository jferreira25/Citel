﻿using AutoMapper;
using Citel.Admin.Compras.Domain.Commands.Product.Create;
using Citel.Admin.Compras.Domain.Commands.Product.Update;
using Citel.Admin.Compras.Domain.Entities;
using Citel.Admin.Compras.Domain.Queries.Product.GetAllProducts;
using Citel.Admin.Compras.Domain.Queries.Product.GetProductById;
using System.Collections.Generic;

namespace Citel.Admin.Compras.Domain.MappersProfile
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<CreateProductCommand, Product>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());

            CreateMap<Product, GetProductByIdQueryResponse>();

            CreateMap<Product, GetProductQueryResponse>();

            CreateMap<List<Product>, GetAllProductsQueryResponse>()
                .ForMember(dest => dest.Products, opt => opt.MapFrom(src => src));

            CreateMap<UpdateProductCommand, Product>();
               

        }
    }
}
