﻿using AutoMapper;
using Citel.Admin.Compras.Domain.Commands.Category.Create;
using Citel.Admin.Compras.Domain.Commands.Category.Update;
using Citel.Admin.Compras.Domain.Entities;
using Citel.Admin.Compras.Domain.Queries.Category.GetAllCategories;
using Citel.Admin.Compras.Domain.Queries.Category.GetCategoryById;
using System.Collections.Generic;

namespace Citel.Admin.Compras.Domain.MappersProfile
{
    public class CategoryProfile : Profile
    {
        public CategoryProfile()
        {
            CreateMap<CreateCategoryCommand, Category>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());

            CreateMap<Category, GetCategoryByIdQueryResponse>();

            CreateMap<Category, GetCategoryQueryResponse>();

            CreateMap<List<Category>, GetAllCategoriesQueryResponse>()
             .ForMember(dest => dest.Categories, opt => opt.MapFrom(src => src));

            CreateMap<UpdateCategoryCommand, Category>();


        }
    }
}
