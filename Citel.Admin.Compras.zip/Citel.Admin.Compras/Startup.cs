using AutoMapper;
using Citel.Admin.Compras.Domain.Commands.Category.Create;
using Citel.Admin.Compras.Domain.Commands.Product.Create;
using Citel.Admin.Compras.Domain.Interfaces;
using Citel.Admin.Compras.Infrastructure.Data.Repository.Category;
using Citel.Admin.Compras.Infrastructure.Data.Repository.Product;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using SimpleInjector;
using SimpleInjector.Lifestyles;
using System.Reflection;

namespace Citel.Admin.Compras
{
    public class Startup
    {
        public Container DependencyInjectionContainer { get; } = new Container();

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;

            DependencyInjectionContainer.Options.DefaultLifestyle = Lifestyle.Scoped;
            DependencyInjectionContainer.Options.DefaultScopedLifestyle = new AsyncScopedLifestyle();
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.UseSimpleInjectorAspNetRequestScoping(DependencyInjectionContainer);
            services.AddMediatR(typeof(CreateProductCommand).GetTypeInfo().Assembly, typeof(CreateCategoryCommand).GetTypeInfo().Assembly);
            services.AddScoped(typeof(IProductRepository), typeof(ProductRepository));
            services.AddScoped(typeof(ICategoryRepository), typeof(CategoryRepository));
            services.AddAutoMapper();

            services.AddControllersWithViews();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "CITEL API",
                    Description = "Api para avalia��o t�cnica"
                });
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseSwagger();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Citel Admin V1");
            });

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }

    }
}
