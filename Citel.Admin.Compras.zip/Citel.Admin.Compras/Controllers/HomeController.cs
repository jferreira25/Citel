﻿using Citel.Admin.Compras.Helper;
using Citel.Admin.Compras.Models;
using Citel.Admin.Compras.Request.Product;
using Citel.Admin.Compras.Response.Model;
using Citel.Admin.Compras.Response.ProductResponse;
using Citel.Admin.Compras.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Citel.Admin.Compras.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            HttpHelper.CreateRequest("https://localhost:44363/");
            HttpHelper.CreateContentRequestUTF8("", "application/json");

            var product = HttpHelper.GetAsync<ProductResponse<ProductListModel>>("api/v1/products").Result;

            var productsViewModel = TransformProductViewModel(product.Data);

            return View(productsViewModel);
        }

        public IActionResult EditProduct(long id)
        {
            var productViewModel = new ProductViewModel();

            productViewModel.Categories = TransformCategoryViewModel(GetAllCategories());

            if (id == 0)
                return View("EditProduct", productViewModel);

            HttpHelper.CreateRequest("https://localhost:44363/");
            HttpHelper.CreateContentRequestUTF8("", "application/json");

            var product = HttpHelper.GetAsync<ProductResponse<ProductModel>>($"api/v1/products/{id}").Result;

            productViewModel.Name = product.Data.Name;
            productViewModel.Price = product.Data.Price;
            productViewModel.Description = product.Data.Description;
            productViewModel.Id = product.Data.Id;

            return View("EditProduct", productViewModel);
        }

        public IActionResult RemoveProduct(long id)
        {
            HttpHelper.CreateRequest("https://localhost:44363/");
            HttpHelper.CreateContentRequestUTF8("", "application/json");

            var product = HttpHelper.DeleteAsync<ProductResponse<ProductModel>>($"api/v1/products/{id}").Result;

            var productViewModel = new ProductViewModel() { IsDeleted = true,Categories = TransformCategoryViewModel(GetAllCategories()) };

            return View("EditProduct", productViewModel);
        }

        public  IActionResult AddOrUpdateProduct(ProductViewModel productModel)
        {
            ProductResponse<ProductModel> product = new ProductResponse<ProductModel>();

            HttpHelper.CreateRequest("https://localhost:44363/");

            var addProduct = new ProductRequest()
            {
                Price = productModel.Price,
                Name = productModel.Name,
                Description = productModel.Description,
                Category = productModel.CategoryId,
                Id = productModel.Id
            };

            HttpHelper.CreateContentRequestUTF8(addProduct, "application/json");

            if (productModel.Id == 0)
            {
                product = HttpHelper.SendAsync<ProductResponse<ProductModel>>("api/v1/products").Result;
                productModel.Id = product.Data.Id;

            }
            else
            {
                HttpHelper.PutAsync<ProductResponse<ProductModel>>("api/v1/products").GetAwaiter();
            }
            productModel.IsCreateOrUpdate = true;
            productModel.Categories = TransformCategoryViewModel(GetAllCategories());

            return View("EditProduct", productModel);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Category()
        {
            var categoriesViewModel = TransformCategoriesViewModel(GetAllCategories());

            return View(categoriesViewModel);
        }

        public IActionResult EditCategory(long id)
        {
            var categoryViewModel = new CategoryViewModel();

            if (id == 0)
                return View("EditCategory", categoryViewModel);

            HttpHelper.CreateRequest("https://localhost:44363/");
            HttpHelper.CreateContentRequestUTF8("", "application/json");

            var category = HttpHelper.GetAsync<CategoryResponse<CategoryModel>>($"api/v1/categories/{id}").Result;

            categoryViewModel.Name = category.Data.Name;
            categoryViewModel.Description = category.Data.Description;
            categoryViewModel.Id = category.Data.Id;

            return View("EditCategory", categoryViewModel);
        }

        public IActionResult RemoveCategory(long id)
        {
            var categoryViewModel = new CategoryViewModel();
            HttpHelper.CreateRequest("https://localhost:44363/");
            HttpHelper.CreateContentRequestUTF8("", "application/json");

            try
            {
                var x = HttpHelper.DeleteAsync<CategoryResponse<CategoryModel>>($"api/v1/categories/{id}").Result;
                categoryViewModel.IsDeleted = true ;
            }
            catch
            {
                categoryViewModel.Error = "Ops Ocorreu um erro :(";
            }
           
           
            return View("EditCategory", categoryViewModel);
        }

        public IActionResult AddOrUpdateCategory(CategoryViewModel categoryModel)
        {
            CategoryResponse<CategoryModel> product = new CategoryResponse<CategoryModel>();

            HttpHelper.CreateRequest("https://localhost:44363/");

            var addCategory = new ProductRequest()
            {
                Name = categoryModel.Name,
                Description = categoryModel.Description,
                Id = categoryModel.Id
            };

            HttpHelper.CreateContentRequestUTF8(addCategory, "application/json");

            if (categoryModel.Id == 0)
            {
                product = HttpHelper.SendAsync<CategoryResponse<CategoryModel>>("api/v1/categories").Result;
                categoryModel.Id = product.Data.Id;
            }
            else
            {
                HttpHelper.PutAsync<CategoryResponse<CategoryModel>>("api/v1/categories").GetAwaiter();
            }
            categoryModel.IsCreateOrUpdate = true;
            

            return View("EditCategory", categoryModel);
        }

        private List<CategoryViewModel> TransformCategoryViewModel(CategoryListModel categoryList)
        {
            var array = new CategoryViewModel[categoryList.Categories.Length];

            for (int i = 0; i < array.Length; i++)
            {
                array[i] = new CategoryViewModel()
                {
                    Description = categoryList.Categories[i].Description,
                    Id = categoryList.Categories[i].Id,
                    Name = categoryList.Categories[i].Name
                };
            }
            return array.ToList();
        }

        private CategoryListModel GetAllCategories()
        {
            HttpHelper.CreateRequest("https://localhost:44363/");
            HttpHelper.CreateContentRequestUTF8("", "application/json");

            var category = HttpHelper.GetAsync<CategoryResponse<CategoryListModel>>($"api/v1/categories").Result;
            return category.Data;
        }
        private ProductListViewModel TransformProductViewModel(ProductListModel productList)
        {
            var productsViewModel = new ProductListViewModel()
            {
                Products = new ProductViewModel[productList.Products.Length]
            };

            for (int i = 0; i < productsViewModel.Products.Length; i++)
            {
                productsViewModel.Products[i] = new ProductViewModel()
                {
                    Description = productList.Products[i].Description,
                    Id = productList.Products[i].Id,
                    Name = productList.Products[i].Name,
                    Price = productList.Products[i].Price
                };
            }
            return productsViewModel;
        }

        private CategoryListViewModel TransformCategoriesViewModel(CategoryListModel categoryList)
        {
            var categoriesViewModel = new CategoryListViewModel()
            {
                Categories = new CategoryViewModel[categoryList.Categories.Length]
            };

            for (int i = 0; i < categoriesViewModel.Categories.Length; i++)
            {
                categoriesViewModel.Categories[i] = new CategoryViewModel()
                {
                    Description = categoryList.Categories[i].Description,
                    Id = categoryList.Categories[i].Id,
                    Name = categoryList.Categories[i].Name
                };
            }
            return categoriesViewModel;
        }
    }
}
