﻿using Citel.Admin.Compras.Domain.Commands.Product;
using Citel.Admin.Compras.Domain.Commands.Product.Create;
using Citel.Admin.Compras.Domain.Commands.Product.Delete;
using Citel.Admin.Compras.Domain.Commands.Product.Update;
using Citel.Admin.Compras.Domain.Queries.Product.GetAllProducts;
using Citel.Admin.Compras.Domain.Queries.Product.GetProductById;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Controllers
{
    [Route("api/v1/products")]
    public class ProductController : BaseController<ProductController>
    {
        public ProductController(IMediator mediatorService) : base(mediatorService)
        {
        }

        [HttpPost]
        public async Task<IActionResult> CreateProductAsync([FromBody] CreateProductCommand command)
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(command));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductAsync(long id)
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(new GetProductByIdQuery(id)));
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProductAsync()
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(new GetAllProductsQuery()));
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProductAsync([FromBody] UpdateProductCommand command)
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(command));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProductAsync(long id)
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(new DeleteProductCommand(id)));
        }

    }
}
