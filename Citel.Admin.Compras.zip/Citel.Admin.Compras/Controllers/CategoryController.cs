﻿using Citel.Admin.Compras.Domain.Commands.Category.Create;
using Citel.Admin.Compras.Domain.Commands.Category.Delete;
using Citel.Admin.Compras.Domain.Commands.Category.Update;
using Citel.Admin.Compras.Domain.Queries.Category.GetAllCategories;
using Citel.Admin.Compras.Domain.Queries.Category.GetCategoryById;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Controllers
{
    [Route("api/v1/categories")]
    public class CategoryController : BaseController<CategoryController>
    {
        public CategoryController(IMediator mediatorService) : base(mediatorService)
        {
        }

        [HttpPost]
        public async Task<IActionResult> CreateCategoryAsync([FromBody] CreateCategoryCommand command)
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(command));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetCategoryAsync(long id)
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(new GetCategoryByIdQuery(id)));
        }

        [HttpGet]
        public async Task<IActionResult> GetAllCategoriesAsync()
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(new GetAllCategoriesQuery()));
        }

        [HttpPut]
        public async Task<IActionResult> UpdateCategoryAsync([FromBody] UpdateCategoryCommand command)
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(command));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategoryAsync(long id)
        {
            return await GenerateResponseAsync(async () => await MediatorService.Send(new DeleteCategoryCommand(id)));
        }
    }
}
