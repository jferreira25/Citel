﻿namespace Citel.Admin.Compras.ViewModels
{
    public class CategoryListViewModel
    {
        public CategoryViewModel[] Categories { get; set; }
    }
   
    public class CategoryViewModel
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsCreateOrUpdate { get; set; }
        public string Error { get; set; }

    }
}
