﻿namespace Citel.Admin.Compras.Response
{
    public class ResponseBase<T>
    {
        public T Data { get; set; }
    }
}
