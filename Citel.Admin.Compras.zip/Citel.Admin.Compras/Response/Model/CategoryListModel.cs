﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Response.Model
{
    public class CategoryListModel
    {
        public CategoryModel[] Categories { get; set; }
    }

    public class CategoryModel
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
