﻿using System.Collections.Generic;

namespace Citel.Admin.Compras.Response.Model
{
    public class ProductListModel 
    {
        public ProductModel[] Products { get; set; }
       
    }
    public class ProductModel
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public long Category { get; set; }
    }
}
