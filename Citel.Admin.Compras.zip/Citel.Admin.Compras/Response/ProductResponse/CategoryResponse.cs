﻿namespace Citel.Admin.Compras.Response.ProductResponse
{
    public class CategoryResponse<T> : ResponseBase<T>
    {
    }
}
