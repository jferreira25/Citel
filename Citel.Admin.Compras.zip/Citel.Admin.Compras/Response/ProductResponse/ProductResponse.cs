﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Citel.Admin.Compras.Response.ProductResponse
{
    public class ProductResponse<T> : ResponseBase<T>
    {
      
    }
}
