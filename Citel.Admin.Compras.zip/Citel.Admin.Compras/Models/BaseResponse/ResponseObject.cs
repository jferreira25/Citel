﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Citel.Admin.Compras.Models.BaseResponse
{
    [Serializable]
    public class ResponseObject<TDataObject>
    {
        [JsonProperty("data")]
        public TDataObject Data { get; set; }
    }
}
