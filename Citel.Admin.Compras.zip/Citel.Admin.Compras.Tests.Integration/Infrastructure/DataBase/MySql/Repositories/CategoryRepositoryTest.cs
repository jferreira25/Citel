﻿using Citel.Admin.Compras.Infrastructure.Data.Repository.Category;
using Citel.Admin.Compras.Tests.Shared.Mock.Domain.Entities.Category;
using FluentAssertions;
using NUnit.Framework;
using System.Threading.Tasks;
using System.Transactions;

namespace Citel.Admin.Compras.Tests.Integration.Infrastructure.DataBase.MySql.Repositories
{
    class CategoryRepositoryTest
    {
        private TransactionScope _transactionScope;
       
        private readonly CategoryRepository _categoryRepository;

        public CategoryRepositoryTest()
        {
            _categoryRepository = new CategoryRepository();
        }

        [SetUp]
        public void TransactionSetUp()
        {
            _transactionScope = CrossCutting.Configuration.
                Transaction.GetTransactionAsync(60);
        }

        [TearDown]
        public void TransactionTearDown()
        {
            _transactionScope.Dispose();
        }

        [TestCase(TestName = "Success Test Add Category")]
        public async Task Test_AddCategory()
        {
            var id = await InsertCategory();
            id.Should().BeGreaterThan(0);
        }

        [TestCase(TestName = "Success Test GetAll Category")]
        public async Task Test_GetAllCategory()
        {
            var Categorys = await _categoryRepository.GetAllAsync();
            Categorys.Should().HaveCountGreaterThan(0);
        }

        [TestCase(TestName = "Sucess Test Update Category")]
        public async Task Test_UpdateCategoryAsync()
        {
            var category = CategoryMock.GetDefaultInstance();
            category.Id = await _categoryRepository.AddAsync(category);

         
            category.Description = "testando mock 2";
            category.Name = "testando mock update";

            await _categoryRepository.UpdateAsync(category);

            var CategoryUpdated = await _categoryRepository.GetByIdAsync(category.Id);

            CategoryUpdated.Name.Should().Be("testando mock update");
        }

        [TestCase(TestName = "Sucess Test Delete Category")]
        public async Task Test_DeleteCategoryAsync()
        {
            var category = CategoryMock.GetDefaultInstance();
            category.Id = await _categoryRepository.AddAsync(category);
           
            category.Description = "testando mock delete";
            category.Name = "testando mock delete";

            await _categoryRepository.DeleteAsync(category.Id);

            var CategoryIsDeleted = await _categoryRepository.DeleteAsync(category.Id);
            CategoryIsDeleted.Should().BeTrue();

        }

        private async Task<long> InsertCategory()
        {
            var category = CategoryMock.GetDefaultInstance();
            var id = await _categoryRepository.AddAsync(category);
            return id;
        }
    }
}
