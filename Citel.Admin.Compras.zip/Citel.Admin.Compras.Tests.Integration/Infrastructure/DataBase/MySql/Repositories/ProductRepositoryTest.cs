﻿using Citel.Admin.Compras.Infrastructure.Data.Repository.Category;
using Citel.Admin.Compras.Infrastructure.Data.Repository.Product;
using Citel.Admin.Compras.Tests.Shared.Mock.Domain.Entities.Product;
using FluentAssertions;
using NUnit.Framework;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;

namespace Citel.Admin.Compras.Tests.Integration.Infrastructure.DataBase.MySql.Repositories
{
    public class ProductRepositoryTest
    {
        private TransactionScope _transactionScope;
        private readonly ProductRepository _productRepository;
        private readonly CategoryRepository _categoryRepository;

        public ProductRepositoryTest()
        {
            _productRepository = new ProductRepository();
            _categoryRepository = new CategoryRepository();
        }

        [SetUp]
        public void TransactionSetUp()
        {
            _transactionScope = CrossCutting.Configuration.
                Transaction.GetTransactionAsync(60);
        }

        [TearDown]
        public void TransactionTearDown()
        {
            _transactionScope.Dispose();
        }

        [TestCase(TestName = "Success Test Add Product")]
        public async Task Test_AddProduct()
        {
            var id = await InsertProduct();
            id.Should().BeGreaterThan(0);
        }

        [TestCase(TestName = "Success Test GetAll Product")]
        public async Task Test_GetAllProduct()
        {
            var products = await _productRepository.GetAllAsync();
            products.Should().HaveCountGreaterThan(0);
        }

        [TestCase(TestName = "Sucess Test Update Product")]
        public async Task Test_UpdateProductAsync()
        {
            var product = ProductMock.GetDefaultInstance();
            product.Id = await _productRepository.AddAsync(product);

            product.Category = 1;
            product.Description = "testando mock 2";
            product.Name = "testando mock update";
            product.Price = 20.99;

            await _productRepository.UpdateAsync(product);

            var productUpdated = await _productRepository.GetByIdAsync(product.Id);

            productUpdated.Name.Should().Be("testando mock update");
            productUpdated.Category.Should().Be(1);
            productUpdated.Price.Should().Be(20.99);
        }

        [TestCase(TestName = "Sucess Test Delete Product")]
        public async Task Test_DeleteProductAsync()
        {
            var product = ProductMock.GetDefaultInstance();
            product.Id = await _productRepository.AddAsync(product);

            product.Category = 1;
            product.Description = "testando mock delete";
            product.Name = "testando mock delete";
            product.Price = 20.99;

            await _productRepository.DeleteAsync(product.Id);

            var productIsDeleted = await _productRepository.DeleteAsync(product.Id);
            productIsDeleted.Should().BeTrue();
           
        }

        private async Task<long> InsertProduct()
        {
            var product = ProductMock.GetDefaultInstance();
            product.Category = (await _categoryRepository.GetAllAsync()).FirstOrDefault().Id;
            var id = await _productRepository.AddAsync(product);
            return id;
        }
    }
}
